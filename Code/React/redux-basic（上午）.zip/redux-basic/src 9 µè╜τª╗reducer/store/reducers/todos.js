// todos 案例的 reducer
const todosReducer = (state = [], action) => {
  return state
}

export default todosReducer
