import CartHeader from './components/CartHeader'

const App = () => {
  return (
    <div>
      <CartHeader>购物车案例</CartHeader>
    </div>
  )
}

export default App
