const App = () => {
  return <div>购物车案例</div>
}

export default App
