// acction type 常量
const INCREMENT = 'counter/increment'
const INCREMENT1 = 'counter/increment1'

export { INCREMENT, INCREMENT1 }
